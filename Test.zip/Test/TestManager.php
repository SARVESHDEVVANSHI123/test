<?php
namespace App\Components\Test;

use Phalcon\Di\Injectable;

class TestManager extends Injectable
{
    public function getAds($data)
    {
        print_r($this);
        print_r($data);
        echo "<br>";
    }

    public function getCampaigns($data)
    {
        print_r($this);
        print_r($data);
        echo "<br>";
    }

    public function getAdsets($data)
    {
        print_r($this);
        print_r($data);
        echo "<br>";
    }

    public function deleteCampaigns($data)
    {
        print_r($this);
        print_r($data);
        echo "<br>";
    }

    public function updateCampaigns($data)
    {
        print_r($this);
        print_r($data);
        echo "<br>";
    }

    public function indexAction()
    {
        $data1 = ["className" => "getCampaigns"];
        $data2 = ["className" => "getAds"];
        $data3 = ["className" => "getAdsets"];
        $data4 = ["className" => "deleteCampaigns"];
        $data5 = ["className" => "updateCampaigns"];

        $manager = new TestManager();

        $getCampaigns = new TestModel($manager);
        $updateCampaigns = new TestModel($manager);
        $getAds = new TestModel($manager);
        $getAdsets = new TestModel($manager);
        $deleteCampaigns = new TestModel($manager);

        $getCampaigns->setClassName("getCampaigns");
        $updateCampaigns->setClassName("updateCampaigns");
        $deleteCampaigns->setClassName("deleteCampaigns");
        $getAds->setClassName("getAds");
        $getAdsets->setClassName("getAdsets");

        $getCampaigns->execute($data1);
        $updateCampaigns->execute($data5);
        $deleteCampaigns->execute($data4);
        $getAds->execute($data2);
        $getAdsets->execute($data3);

    }
}