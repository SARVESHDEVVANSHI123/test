<?php

namespace App\Components\Test;

class TestModel implements TestManagerInterface
{
    private $managerclass;
    private $className;

    public function __construct(TestManager $managerclass)
    {
        $this->managerclass = $managerclass;
    }

    public function setClassName($className)
    {
        $this->className = $className;
    }
    public function execute($data)
    {
        $className = $this->className;
        $this->managerclass->$className($data);
    }
}