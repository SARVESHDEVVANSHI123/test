<?php
namespace App\Components\Test;

interface TestManagerInterface
{
    public function execute($data);
}